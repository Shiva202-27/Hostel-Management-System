public class Drive {
    public static void main(String[] args) {
        HostelManagementSystem HMS = new HostelManagementSystem();
        System.out.println("\n\t\t\t\t\t\t\t\t\t\t******************************************************");
        System.out.println("\t\t\t\t\t\t\t\t\t\t✦✦✦ WELCOME  TO BUSTERS HOSTEL MANAGEMENT SYSTEM ✦✦✦");
        System.out.println("\t\t\t\t\t\t\t\t\t\t******************************************************\n\n");

        HMS.login();
        HMS.mainmenu();

    }

}
